const model = document.querySelector('.model')

model.addEventListener('click', () => {
  model.style.display = 'none'
})
export default model