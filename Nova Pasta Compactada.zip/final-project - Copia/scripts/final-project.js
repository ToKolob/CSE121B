import model from './model.js'; // Make sure the model.js file exists and contains the necessary code

const apiKey = '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';
const endpoint = 'https://api.openai.com/v1/completions';

const sendButton = document.getElementById('send-button');
sendButton.addEventListener('click', sendMessage);

async function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    const chatBox = document.getElementById('chat-box');
    
    // Display user message
    chatBox.innerHTML += `<p>You: ${userInput}</p>`;

    try {
        // Send user message to ChatGPT API
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'text-davinci-003', // Specify the model you want to use
                prompt: userInput,
                max_tokens: 100,
                temperature: 0.5            
            })
        });

        const data = await response.json();

        // Display ChatGPT response
        chatBox.innerHTML += `<p>ChatGPT: ${data.choices[0].text}</p>`;

    } catch (error) {
        console.error(error);
    }

    // Clear input field
    document.getElementById('user-input').value = '';
}